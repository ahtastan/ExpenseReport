from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from openpyxl import load_workbook
from sqlmodel import Session, select

from app.config import get_settings
from app.models import MatchDecision, ReceiptDocument, ReportRun, StatementTransaction
from app.services import model_router
from app.services.receipt_annotations import ReceiptAnnotationLine, create_annotated_receipts_pdf
from app.services.report_validation import ReportValidation, validate_report_readiness
from app.services.review_sessions import confirmed_snapshot


DEFAULT_BUSINESS_REASONS = {
    date(2026, 3, 11): "Kartonsan Service Visit",
    date(2026, 3, 12): "Kartonsan Service Visit",
    date(2026, 3, 13): "Kartonsan Service Visit",
    date(2026, 4, 1): "Sanipak Visit",
}


REPORT_BUCKETS = [
    "Airfare/Bus/Ferry/Other",
    "Hotel/Lodging/Laundry",
    "Auto Rental",
    "Auto Gasoline",
    "Taxi/Parking/Tolls/Uber",
    "Other Travel Related",
    "Membership/Subscription Fees",
    "Customer Gifts",
    "Telephone/Internet",
    "Postage/Shipping",
    "Admin Supplies",
    "Lab Supplies",
    "Field Service Supplies",
    "Assets",
    "Other",
    "Meals/Snacks",
    "Breakfast",
    "Lunch",
    "Dinner",
    "Entertainment",
]


BUCKET_TOTAL_KEYS = {
    "airfare/bus/ferry/other": "airfare",
    "hotel/lodging/laundry": "hotel",
    "auto rental": "auto_rental",
    "auto gasoline": "gas",
    "taxi/parking/tolls/uber": "ground",
    "other travel related": "travel_other",
    "membership/subscription fees": "membership",
    "customer gifts": "gifts",
    "telephone/internet": "phone",
    "postage/shipping": "postage",
    "admin supplies": "admin",
    "lab supplies": "lab",
    "field service supplies": "field_service",
    "assets": "assets",
    "other": "other",
    "meals/snacks": "meal_m",
    "breakfast": "meal_b",
    "lunch": "meal_l",
    "dinner": "meal_d",
    "entertainment": "ent",
}


MEAL_DETAIL_CODES = {
    "meal_m": "M",
    "meal_b": "B",
    "meal_l": "L",
    "meal_d": "D",
    "ent": "E",
}


def _bucket_key(bucket: str) -> str:
    return " ".join(bucket.lower().replace("(", "").replace(")", "").split())


AIRFARE_BUCKET = "Airfare/Bus/Ferry/Other"

# Row layout for the AIR TRAVEL RECONCILIATION section per sheet.
# Week 1A: title=44, headers=45-46, data=47-49.
# Week 2A: title=45, headers=46-47, data=48-50.
AIR_TRAVEL_ROWS_BY_SHEET = {
    "Week 1A": [47, 48, 49],
    "Week 2A": [48, 49, 50],
}


@dataclass(frozen=True)
class MealDetailLine:
    tx_date: date
    code: str
    place: str
    location: str
    participants: str
    reason: str
    amount: float
    eg: bool
    mr: bool


@dataclass(frozen=True)
class ReportLine:
    transaction_id: int
    receipt_id: int | None
    receipt_path: str | None
    receipt_file_name: str
    transaction_date: date
    supplier: str
    amount: float
    currency: str
    business_or_personal: str
    report_bucket: str
    business_reason: str
    attendees: str
    air_travel_date: date | None = None
    air_travel_from: str | None = None
    air_travel_to: str | None = None
    air_travel_airline: str | None = None
    air_travel_rt_or_oneway: str | None = None
    air_travel_return_date: date | None = None
    air_travel_paid_by: str | None = None
    air_travel_total_tkt_cost: float | None = None
    air_travel_prior_tkt_value: float | None = None
    air_travel_comments: str | None = None
    meal_place: str | None = None
    meal_location: str | None = None
    meal_eg: bool = False
    meal_mr: bool = False


def _approved_lines(session: Session, statement_import_id: int) -> list[ReportLine]:
    transactions = {
        tx.id: tx
        for tx in session.exec(
            select(StatementTransaction).where(StatementTransaction.statement_import_id == statement_import_id)
        ).all()
        if tx.id is not None
    }
    decisions = [
        decision
        for decision in session.exec(select(MatchDecision).where(MatchDecision.approved == True)).all()  # noqa: E712
        if decision.statement_transaction_id in transactions
    ]
    lines: list[ReportLine] = []
    for decision in decisions:
        tx = transactions.get(decision.statement_transaction_id)
        receipt = session.get(ReceiptDocument, decision.receipt_document_id)
        if not tx or not receipt or tx.id is None or receipt.id is None:
            continue
        tx_date = tx.transaction_date or receipt.extracted_date
        amount = tx.usd_amount if tx.usd_amount is not None else tx.local_amount
        if not tx_date or amount is None:
            continue
        business_reason = (
            receipt.business_reason
            or DEFAULT_BUSINESS_REASONS.get(tx_date)
            or ("Personal spending on Diners card" if (receipt.business_or_personal or "").lower() != "business" else "")
        )
        lines.append(
            ReportLine(
                transaction_id=tx.id,
                receipt_id=receipt.id,
                receipt_path=receipt.storage_path,
                receipt_file_name=receipt.original_file_name or f"receipt_{receipt.id}",
                transaction_date=tx_date,
                supplier=tx.supplier_raw,
                amount=float(amount),
                currency="USD" if tx.usd_amount is not None else tx.local_currency,
                business_or_personal=receipt.business_or_personal or "",
                report_bucket=receipt.report_bucket or "",
                business_reason=business_reason,
                attendees=receipt.attendees or "",
            )
        )
    return sorted(lines, key=lambda line: (line.transaction_date, line.transaction_id))


def _parse_optional_date(value: object) -> date | None:
    if value in (None, ""):
        return None
    try:
        return date.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None


def _parse_optional_float(value: object) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None


def _parse_bool(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if value in (None, ""):
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "y", "on", "eg", "mr"}


def _confirmed_lines(session: Session, statement_import_id: int) -> list[ReportLine]:
    _review, snapshot = confirmed_snapshot(session, statement_import_id)
    lines: list[ReportLine] = []
    for row in snapshot:
        tx_date_raw = row.get("transaction_date")
        amount = row.get("amount")
        if not tx_date_raw or amount is None:
            continue
        tx_date = date.fromisoformat(str(tx_date_raw))
        lines.append(
            ReportLine(
                transaction_id=int(row["transaction_id"]),
                receipt_id=int(row["receipt_id"]) if row.get("receipt_id") is not None else None,
                receipt_path=row.get("receipt_path"),
                receipt_file_name=row.get("receipt_file_name") or f"receipt_{row.get('receipt_id')}",
                transaction_date=tx_date,
                supplier=row.get("supplier") or "",
                amount=float(amount),
                currency=row.get("currency") or "TRY",
                business_or_personal=row.get("business_or_personal") or "",
                report_bucket=row.get("report_bucket") or "",
                business_reason=row.get("business_reason") or "",
                attendees=row.get("attendees") or "",
                air_travel_date=_parse_optional_date(row.get("air_travel_date")) or tx_date,
                air_travel_from=row.get("air_travel_from") or None,
                air_travel_to=row.get("air_travel_to") or None,
                air_travel_airline=row.get("air_travel_airline") or None,
                air_travel_rt_or_oneway=row.get("air_travel_rt_or_oneway") or None,
                air_travel_return_date=_parse_optional_date(row.get("air_travel_return_date")),
                air_travel_paid_by=row.get("air_travel_paid_by") or None,
                air_travel_total_tkt_cost=_parse_optional_float(row.get("air_travel_total_tkt_cost")),
                air_travel_prior_tkt_value=_parse_optional_float(row.get("air_travel_prior_tkt_value")),
                air_travel_comments=row.get("air_travel_comments") or None,
                meal_place=row.get("meal_place") or None,
                meal_location=row.get("meal_location") or None,
                meal_eg=_parse_bool(row.get("meal_eg")),
                meal_mr=_parse_bool(row.get("meal_mr")),
            )
        )
    return sorted(lines, key=lambda line: (line.transaction_date, line.transaction_id))


def _allocate(line: ReportLine, day_totals: dict[date, dict[str, list[float]]], detail_lines: dict[date, list[MealDetailLine]]) -> None:
    bp = line.business_or_personal.lower()
    day = day_totals[line.transaction_date]
    if bp != "business":
        day["other"].append(line.amount)
        return

    bucket_key = _bucket_key(line.report_bucket)
    total_key = BUCKET_TOTAL_KEYS.get(bucket_key, "other")
    total_amount = line.amount
    if bucket_key == _bucket_key(AIRFARE_BUCKET) and line.air_travel_total_tkt_cost is not None:
        total_amount = line.air_travel_total_tkt_cost
    day[total_key].append(total_amount)
    if total_key in MEAL_DETAIL_CODES:
        detail_lines[line.transaction_date].append(
            MealDetailLine(
                tx_date=line.transaction_date,
                code=MEAL_DETAIL_CODES[total_key],
                place=line.meal_place or line.supplier,
                location=line.meal_location or "",
                participants=line.attendees,
                reason=line.business_reason,
                amount=total_amount,
                eg=line.meal_eg,
                mr=line.meal_mr,
            )
        )


def _fill_workbook(template_path: Path, output_path: Path, employee_name: str, title: str, lines: list[ReportLine]) -> None:
    wb = load_workbook(template_path)
    ws1a, ws1b, ws2a, ws2b = wb["Week 1A"], wb["Week 1B"], wb["Week 2A"], wb["Week 2B"]
    ws1a["B3"] = employee_name
    ws1a["G3"] = title

    day_totals: dict[date, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    detail_lines: dict[date, list[MealDetailLine]] = defaultdict(list)
    for line in lines:
        _allocate(line, day_totals, detail_lines)

    dates = sorted({line.transaction_date for line in lines})
    first7, next7 = dates[:7], dates[7:14]
    cols = ["E", "F", "G", "H", "I", "J", "K"]

    def fill_a(ws, page_dates: list[date]) -> None:
        def total_value(amounts: list[float] | None) -> float | str | None:
            if not amounts:
                return None
            if len(amounts) == 1:
                return amounts[0]
            parts = [f"{amount:.2f}".rstrip("0").rstrip(".") for amount in amounts]
            return "=" + "+".join(parts)

        for col, tx_date in zip(cols, page_dates):
            vals = day_totals[tx_date]
            ws[f"{col}5"] = datetime(tx_date.year, tx_date.month, tx_date.day)
            ws[f"{col}6"] = DEFAULT_BUSINESS_REASONS.get(tx_date, "")
            ws[f"{col}7"] = total_value(vals.get("airfare"))
            ws[f"{col}8"] = total_value(vals.get("hotel"))
            ws[f"{col}9"] = total_value(vals.get("auto_rental"))
            ws[f"{col}10"] = total_value(vals.get("gas"))
            ws[f"{col}11"] = total_value(vals.get("ground"))
            ws[f"{col}14"] = total_value(vals.get("travel_other"))
            ws[f"{col}18"] = total_value(vals.get("membership"))
            ws[f"{col}19"] = total_value(vals.get("gifts"))
            ws[f"{col}20"] = total_value(vals.get("phone"))
            ws[f"{col}21"] = total_value(vals.get("postage"))
            ws[f"{col}22"] = total_value(vals.get("admin"))
            ws[f"{col}23"] = total_value(vals.get("lab"))
            ws[f"{col}24"] = total_value(vals.get("field_service"))
            ws[f"{col}25"] = total_value(vals.get("assets"))
            ws[f"{col}26"] = total_value(vals.get("other"))
            ws[f"{col}29"] = total_value(vals.get("meal_m"))
            ws[f"{col}30"] = total_value(vals.get("meal_b"))
            ws[f"{col}31"] = total_value(vals.get("meal_l"))
            ws[f"{col}32"] = total_value(vals.get("meal_d"))
            ws[f"{col}35"] = total_value(vals.get("ent"))

    def fill_air_travel(ws, sheet_name: str, page_lines: list[ReportLine]) -> None:
        def travel_date_value(ln: ReportLine) -> datetime | str | None:
            travel_date = ln.air_travel_date or ln.transaction_date
            if travel_date is None:
                return None
            if (ln.air_travel_rt_or_oneway or "").strip().upper() == "RT" and ln.air_travel_return_date:
                return f"{travel_date:%d.%m.%Y} - {ln.air_travel_return_date:%d.%m.%Y}"
            return datetime(travel_date.year, travel_date.month, travel_date.day)

        rows = AIR_TRAVEL_ROWS_BY_SHEET.get(sheet_name, [])
        if not rows:
            return
        air_lines = [ln for ln in page_lines if _bucket_key(ln.report_bucket) == _bucket_key(AIRFARE_BUCKET)]
        for row_num, ln in zip(rows, air_lines):
            value = travel_date_value(ln)
            if value is not None:
                ws[f"B{row_num}"] = value
            if ln.air_travel_from:
                ws[f"C{row_num}"] = ln.air_travel_from
            if ln.air_travel_to:
                ws[f"D{row_num}"] = ln.air_travel_to
            if ln.air_travel_airline:
                ws[f"E{row_num}"] = ln.air_travel_airline
            if ln.air_travel_rt_or_oneway:
                ws[f"F{row_num}"] = ln.air_travel_rt_or_oneway
            ws[f"G{row_num}"] = ln.air_travel_paid_by or "DC Card"
            if ln.air_travel_total_tkt_cost is not None:
                ws[f"H{row_num}"] = ln.air_travel_total_tkt_cost
            else:
                # Fall back to the line amount so the formula in column J has a value.
                ws[f"H{row_num}"] = ln.amount
            ws[f"I{row_num}"] = ln.air_travel_prior_tkt_value if ln.air_travel_prior_tkt_value is not None else 0
            # Column J holds the `=H-I` formula in the template — do not overwrite.
            if ln.air_travel_comments:
                ws[f"K{row_num}"] = ln.air_travel_comments

    def fill_b(ws, page_dates: list[date]) -> None:
        code_rows = {"M": 0, "B": 1, "L": 2, "D": 3, "E": 4}
        for day_index, tx_date in enumerate(page_dates):
            used_codes: set[str] = set()
            for detail in detail_lines.get(tx_date, []):
                if detail.code not in code_rows or detail.code in used_codes:
                    continue
                used_codes.add(detail.code)
                rownum = 8 + day_index * 5 + code_rows[detail.code]
                ws[f"C{rownum}"] = detail.place[:40]
                ws[f"D{rownum}"] = detail.location[:28]
                ws[f"E{rownum}"] = detail.participants[:40]
                ws[f"F{rownum}"] = detail.reason[:50]
                ws[f"H{rownum}"] = "x" if detail.eg else None
                ws[f"I{rownum}"] = "x" if detail.mr else None

    first7_set = set(first7)
    next7_set = set(next7)
    first7_lines = [ln for ln in lines if ln.transaction_date in first7_set]
    next7_lines = [ln for ln in lines if ln.transaction_date in next7_set]

    fill_a(ws1a, first7)
    fill_a(ws2a, next7)
    fill_b(ws1b, first7)
    fill_b(ws2b, next7)
    fill_air_travel(ws1a, "Week 1A", first7_lines)
    fill_air_travel(ws2a, "Week 2A", next7_lines)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_path)


def _write_summary(path: Path, validation: ReportValidation, lines: list[ReportLine], workbook_paths: list[Path]) -> None:
    summary_lines = [
        f"statement_import_id={validation.statement_import_id}",
        f"ready={validation.ready}",
        f"errors={validation.issue_count}",
        f"warnings={validation.warning_count}",
        f"approved_matches={validation.approved_matches}",
        f"report_lines={len(lines)}",
        f"business_receipts={validation.business_receipts}",
        f"personal_receipts={validation.personal_receipts}",
        "workbooks=" + ", ".join(p.name for p in workbook_paths),
        "",
        "issues:",
    ]
    summary_lines.extend(f"{issue.severity}|{issue.code}|{issue.message}" for issue in validation.issues)
    path.write_text("\n".join(summary_lines), encoding="utf-8")


def _bucket_totals(lines: list[ReportLine]) -> dict[str, float]:
    totals: dict[str, float] = defaultdict(float)
    for line in lines:
        amount = line.air_travel_total_tkt_cost if _bucket_key(line.report_bucket) == _bucket_key(AIRFARE_BUCKET) and line.air_travel_total_tkt_cost is not None else line.amount
        totals[line.report_bucket or "Other"] += float(amount)
    return dict(sorted(totals.items()))


def _summary_payload(
    validation: ReportValidation,
    lines: list[ReportLine],
    workbook_paths: list[Path],
    employee_name: str,
    title_prefix: str,
) -> dict:
    business_reasons = sorted({line.business_reason for line in lines if line.business_reason})
    anomalies = [
        {
            "severity": issue.severity,
            "code": issue.code,
            "message": issue.message,
            "review_row_id": issue.review_row_id,
            "supplier": issue.supplier,
            "transaction_date": issue.transaction_date,
        }
        for issue in validation.issues
    ]
    anomalies.extend(
        {
            "severity": "warning",
            "code": "missing_receipt",
            "message": "Report line has no attached receipt file.",
            "transaction_id": line.transaction_id,
            "supplier": line.supplier,
            "transaction_date": line.transaction_date.isoformat(),
        }
        for line in lines
        if line.receipt_id is None or not line.receipt_path
    )
    return {
        "statement_import_id": validation.statement_import_id,
        "employee_name": employee_name,
        "title_prefix": title_prefix,
        "date_range": {
            "start": min((line.transaction_date for line in lines), default=None),
            "end": max((line.transaction_date for line in lines), default=None),
        },
        "trip_purpose_candidates": business_reasons,
        "totals_by_bucket": _bucket_totals(lines),
        "currency": sorted({line.currency for line in lines if line.currency}),
        "line_count": len(lines),
        "workbooks": [path.name for path in workbook_paths],
        "anomalies": anomalies,
    }


def _fallback_summary_markdown(payload: dict) -> str:
    purposes = payload.get("trip_purpose_candidates") or []
    totals = payload.get("totals_by_bucket") or {}
    anomalies = payload.get("anomalies") or []
    currencies = ", ".join(payload.get("currency") or [])
    lines = [
        "# Expense Report Summary",
        "",
        f"Trip purpose: {', '.join(purposes) if purposes else 'Not specified'}.",
        "",
        "Totals by bucket:",
    ]
    if totals:
        lines.extend(f"- {bucket}: {amount:.2f}{(' ' + currencies) if currencies else ''}" for bucket, amount in totals.items())
    else:
        lines.append("- No report lines.")
    lines.extend(["", "Flagged anomalies:"])
    if anomalies:
        lines.extend(f"- {item.get('severity', 'warning')}: {item.get('message', '')}" for item in anomalies)
    else:
        lines.append("- None.")
    return "\n".join(lines)


def _write_synthesis_summary(
    path: Path,
    validation: ReportValidation,
    lines: list[ReportLine],
    workbook_paths: list[Path],
    employee_name: str,
    title_prefix: str,
) -> None:
    payload = _summary_payload(validation, lines, workbook_paths, employee_name, title_prefix)
    summary = model_router.synthesize_report_summary(payload) or _fallback_summary_markdown(payload)
    path.write_text(summary + "\n", encoding="utf-8")


def _annotation_lines(lines: list[ReportLine]) -> list[ReceiptAnnotationLine]:
    return [
        ReceiptAnnotationLine(
            receipt_id=line.receipt_id,
            transaction_id=line.transaction_id,
            receipt_path=line.receipt_path,
            receipt_file_name=line.receipt_file_name,
            transaction_date=line.transaction_date,
            supplier=line.supplier,
            amount=line.amount,
            currency=line.currency,
            business_or_personal=line.business_or_personal,
            report_bucket=line.report_bucket,
            business_reason=line.business_reason,
            attendees=line.attendees,
        )
        for line in lines
    ]


def generate_report_package(
    session: Session,
    statement_import_id: int,
    employee_name: str,
    title_prefix: str,
    allow_warnings: bool = True,
) -> ReportRun:
    settings = get_settings()
    if not settings.report_template_path or not settings.report_template_path.exists():
        raise FileNotFoundError("Expense report template was not found. Set EXPENSE_REPORT_TEMPLATE_PATH.")

    validation = validate_report_readiness(session, statement_import_id)
    if validation.issue_count:
        if any(issue.code == "review_not_confirmed" for issue in validation.issues):
            raise ValueError("Report generation requires confirmed review data")
        raise ValueError(f"Report has {validation.issue_count} blocking validation error(s)")
    if validation.warning_count and not allow_warnings:
        raise ValueError(f"Report has {validation.warning_count} validation warning(s)")

    lines = _confirmed_lines(session, statement_import_id)
    if not lines:
        raise ValueError("No confirmed review rows are available for report generation")

    run = ReportRun(statement_import_id=statement_import_id, template_name=settings.report_template_path.name, status="running")
    session.add(run)
    session.commit()
    session.refresh(run)

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output_dir = settings.storage_root / "reports" / f"report_{run.id}_{timestamp}"
    output_dir.mkdir(parents=True, exist_ok=True)

    dates = sorted({line.transaction_date for line in lines})
    chunks = [dates[i : i + 14] for i in range(0, len(dates), 14)]
    workbook_paths: list[Path] = []
    for idx, chunk_dates in enumerate(chunks, start=1):
        chunk_lines = [line for line in lines if line.transaction_date in set(chunk_dates)]
        title = f"{title_prefix} - Part {idx}" if len(chunks) > 1 else title_prefix
        workbook_path = output_dir / f"expense_report_part_{idx}.xlsx"
        _fill_workbook(settings.report_template_path, workbook_path, employee_name, title, chunk_lines)
        workbook_paths.append(workbook_path)

    summary_path = output_dir / "validation_summary.txt"
    _write_summary(summary_path, validation, lines, workbook_paths)
    synthesis_summary_path = output_dir / "summary.md"
    _write_synthesis_summary(synthesis_summary_path, validation, lines, workbook_paths, employee_name, title_prefix)
    annotated_pdf_path = output_dir / "annotated_receipts.pdf"
    create_annotated_receipts_pdf(_annotation_lines(lines), annotated_pdf_path)

    if len(workbook_paths) == 1 and not annotated_pdf_path.exists():
        final_path = workbook_paths[0]
    else:
        final_path = output_dir / "expense_report_package.zip"
        with ZipFile(final_path, "w", compression=ZIP_DEFLATED) as zf:
            for workbook_path in workbook_paths:
                zf.write(workbook_path, workbook_path.name)
            zf.write(summary_path, summary_path.name)
            zf.write(synthesis_summary_path, synthesis_summary_path.name)
            zf.write(annotated_pdf_path, annotated_pdf_path.name)

    run.status = "completed"
    run.output_workbook_path = str(final_path)
    run.output_pdf_path = str(annotated_pdf_path)
    session.add(run)
    session.commit()
    session.refresh(run)
    return run
